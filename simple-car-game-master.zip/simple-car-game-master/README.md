# Simple Car Game

This game is being developed as a tutorial.

You can access it [here](https://medium.com/@gdomaradzki/how-to-make-a-simple-multiplayer-online-car-game-with-javascript-89d47908f995)

# Build Setup
```bash
# To install, just go to the root folder and run
npm i

# To build the files run
npm run build

# To run as dev
npm run dev

# To run as prod
npm run start
```
